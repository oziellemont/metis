#!/usr/bin/env python3
"""Choose machine guidance from deployment metadata and one message's context."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from urllib.parse import parse_qsl, unquote, urlsplit
from uuid import UUID
from ipaddress import ip_address


_COST = "The machine I run on is still up, so it still costs a little. "
_SENTINELS = {
    "none", "null", "undefined", "unknown", "unset", "changeme", "placeholder",
    "replace_me", "your-host", "your-hostname",
}


def _value(value: object) -> str | None:
    if not isinstance(value, str) or not value or value != value.strip():
        return None
    if value.lower() in _SENTINELS or any(ord(c) < 32 or ord(c) == 127 for c in value):
        return None
    return value


def _uuid(value: object) -> str | None:
    if not isinstance(value, str) or not re.fullmatch(
        r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", value
    ):
        return None
    return str(UUID(value))


def _url(value: object) -> str | None:
    value = _value(value)
    if not value or any(c.isspace() or c in "<>\\\"`()" for c in value):
        return None
    decoded = unquote(value)
    if any(ord(c) < 32 or ord(c) == 127 for c in decoded):
        return None
    try:
        parsed = urlsplit(value)
        if (
            parsed.scheme not in {"http", "https"}
            or not parsed.hostname
            or parsed.hostname.lower() in _SENTINELS | {"0.0.0.0", "internal.invalid"}
            or parsed.username is not None
            or parsed.password is not None
        ):
            return None
        hostname = parsed.hostname.encode("idna").decode("ascii")
        if ":" in hostname:
            ip_address(hostname)
        elif not all(
            re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?", label)
            for label in hostname.rstrip(".").split(".")
        ):
            return None
        parsed.port  # Reject malformed/out-of-range ports as well.
        if any(
            re.search(
                r"token|password|secret|credential|signature|authorization|api.?key|^(code|sig|auth|key)$",
                key, re.I,
            )
            for component in (parsed.query, parsed.fragment)
            for key, _ in parse_qsl(component, keep_blank_values=True)
        ):
            return None
    except (ValueError, UnicodeError):
        return None
    return value


def teardown_guidance(
    metadata: dict, message_context: dict, hosted_url: str | None = None,
    sandbox_metadata: dict | None = None,
) -> str:
    """Return navigation/contact guidance, never authorization or a teardown action."""
    metadata = metadata if isinstance(metadata, dict) else {}
    message_context = message_context if isinstance(message_context, dict) else {}
    managed = metadata.get("machine_management") == "admin_console"
    if managed:
        provider = metadata.get("messaging_channel")
        workspace = _value(metadata.get("workspace_id"))
        message_workspace = _value(message_context.get("workspace_id"))
        scoped = (
            provider in ("slack", "teams")
            and provider == message_context.get("provider")
            and workspace is not None
            and message_workspace is not None
            and (_uuid(workspace) or workspace) == (_uuid(message_workspace) or message_workspace)
        )
        admin = _value(metadata.get("admin_owner_id"))
        if provider == "teams":
            admin = _uuid(admin)
        elif provider == "slack":
            admin = admin if admin and re.fullmatch(r"[UW][A-Z0-9]+", admin) else None
        else:
            admin = None
        sender = message_context.get("sender")
        sender = sender if isinstance(sender, dict) else {}
        sender_id = _value(sender.get("user_id"))
        source = sender.get("user_id_source")
        if provider == "teams":
            sender_id = _uuid(sender_id)
            proven = source in ("teams_aad_object_id", "graph_user")
        else:
            sender_id = (
                sender_id if sender_id and re.fullmatch(r"[UW][A-Z0-9]+", sender_id) else None
            )
            proven = source == "slack_event"
        proven_human = (
            scoped and admin is not None and sender_id is not None and proven
            and sender.get("is_bot") is False
            and not sender.get("app_id") and not sender.get("bot_type")
        )
        if proven_human and sender_id == admin:
            url = _url(metadata.get("admin_ui_url"))
            if url and urlsplit(url).scheme != "https":
                url = None
            console = f"[Ninja admin UI]({url})" if url else "deployment's Ninja admin console"
            return (
                _COST + f"To stop that too, use the {console} for the separate machine teardown. "
                "VPN access, sign-in and admin permissions may be required; being the configured "
                "Ninja admin does not itself grant console access. Tear down is not a reversible Pause/Resume."
            )
        if proven_human:
            return _COST + f"To stop that too, contact your Ninja admin <@{admin}> to tear down the machine."
        return (
            _COST + "To stop that too, contact your deployment operator or use the deployment's "
            "admin console for the separate machine teardown. VPN access, sign-in and admin "
            "permissions may be required. Tear down is not a reversible Pause/Resume."
        )
    sandbox_metadata = sandbox_metadata if isinstance(sandbox_metadata, dict) else {}
    hosted = _value(sandbox_metadata.get("environment")) and (
        _value(sandbox_metadata.get("project_id")) or _value(sandbox_metadata.get("thread_id"))
    )
    if hosted and _url(hosted_url):
        return (
            _COST + "To stop that too, select your project in the main UI and press "
            f"**Pause**: {hosted_url}"
        )
    return (
        _COST + "To stop that too, contact your deployment operator for the separate "
        "machine shutdown; pausing background work does not stop the machine."
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--hosted-url", help="Exact main UI link printed by pause")
    args = parser.parse_args()
    try:
        context = json.load(sys.stdin)
        if not isinstance(context, dict):
            raise ValueError("message context must be a JSON object")
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
    # Source-tree skills and installed Claude/Codex skills share the same runtime.
    root = next(
        (parent for parent in Path(__file__).resolve().parents if (parent / "core" / "metadata.py").is_file()),
        Path("/workspace/ninja"),
    )
    sys.path.insert(0, str(root))
    from core.metadata import load_runtime_metadata, load_sandbox_metadata

    print(teardown_guidance(
        load_runtime_metadata(), context, args.hosted_url, load_sandbox_metadata()
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
