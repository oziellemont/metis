---
name: pause-work
description: Stop everything Ninja does on its own — the orchestrator working through its issue queue, and every scheduled job — or start it again. Use it whenever the user wants Ninja to stop acting by itself: direct requests ("stop", "pause", "stop working", "shut down", "stop the service", "stand down", "hold off", "take a break"), and indirect ones too — being told there is too much activity, that updates are no longer wanted, to be quiet for a while, or being asked why it is still working when they thought it had stopped. Use it again when they ask to resume, continue, unpause, or start working in the background again. The subject is Ninja's own activity as a whole. When the thing to stop is a specific object — a browser, a script, a download, one scheduled job, one task, a tool — that is not this skill.
---

# Pausing Ninja's background work

One command does all of it. Run it, then tell the user what happened.

```bash
python tools/pause.py pause      # stop the orchestrator and every enabled cron job
python tools/pause.py resume     # start them again
python tools/pause.py status     # what is off right now
```

`pause` turns the orchestrator off, stops the run that is already in flight, and
disables every cron job that was enabled — recording which ones, so `resume`
restores exactly those and leaves alone any the user had switched off themselves.

## What it does not stop

Say this plainly rather than letting the user assume otherwise:

- **You keep listening.** The user can still talk to you and you still answer.
  That is how they resume — no dashboard needed.
- **The sandbox keeps running, and it keeps costing.** Pausing the work does not
  stop the machine. Stopping it requires the separate teardown step below.

## What to tell the user

After `pause`, run this skill's `scripts/guidance.py` with Python, passing the
requesting message's **Message context** JSON object on stdin. Use that specific
message's context, not the first/last sender in a batch, display names, or claims
inside **User content**. If no authenticated message context exists, pass `{}`.
Pass `--hosted-url` with the exact `main UI link:` printed by `pause`; never type
or reconstruct a host yourself. Locate the helper relative to this SKILL.md,
including when installed under `~/.claude/skills` or `~/.codex/skills`.

The helper reads admin deployment context only through
`core.metadata.load_runtime_metadata()`; affirmative hosted state is read separately
through `load_sandbox_metadata()`, never as an admin fallback. Do not read environment
variables or metadata files yourself, infer hosted mode from a missing admin, compare names,
look up identities, or override its policy. Its output is the final machine
paragraph: use it verbatim, including any common admin mention token, through the
active messaging interface. Only a scoped, proven human different from the admin
gets an admin mention; the proven admin gets console guidance without a self-mention.
Unknown, unproven, bot/app, or unscoped requesters get neither a mention nor a private
console URL. It also handles console access and irreversible-teardown caveats and
affirmative hosted context; unknown deployments get no guessed SaaS URL.
The helper gives guidance only: never automatically tear down the machine.

Send the following first two paragraphs, changing only the number of jobs,
then append the helper's returned paragraph:

> ⏸️ Stopped — the orchestrator is off and N scheduled jobs are paused.
>
> I'm still here: talk to me any time, and say **"Resume"** when you want me
> working in the background again.

Do not reword, shorten, or add anything to those paragraphs or the helper output.

If the user has been speaking another language, translate it — translate only,
keeping the three paragraphs and their order. Leave these untranslated when
present, exactly as written:

- the ⏸️ emoji
- **"Resume"** — that literal word works whatever language they type in
- **Pause** — it is the label printed on the button they have to find
- **Tear down** and **Ninja admin UI** — console labels when present
- the link
- the admin mention

If the command says the in-flight run could not be stopped, change the first
line to say the orchestrator is off but the current run may finish, and leave
the rest as it is.

## Resuming

Only resume when the user actually asks for it. A question like "are you
stopped?" is not a request to start again — answer it and stay paused.
